// ========== LOGIN ==========
app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await Users.findOne({ email });
    if (!user) {
      return res.status(400).send("❌ Invalid Email or Password");
    }

    if (user.password !== password) {
      return res.status(400).send("❌ Invalid Email or Password");
    }

    // ✅ login successful → dashing.html pe bhejo
    res.redirect("/dashing.html");
  } catch (err) {
    console.error("Login Error:", err);
    res.status(500).send("❌ Server Error during login");
  }
});